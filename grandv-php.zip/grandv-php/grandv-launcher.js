(() => {
  const $ = id => document.getElementById(id);
  const gameUrl = location.origin + '/launcher.html';
  $('link').textContent = gameUrl;

  fetch('/api/status', { cache: 'no-store' }).then(r => r.json()).then(s => {
    const ok = s.gameFolder && s.hasLauncher;
    $('status').innerHTML = ok
      ? '<span class="ok">Running.</span> Game files found.'
      : '<span class="bad">Running, but no game files.</span> Expected <code>mirror/playgta5.com/launcher.html</code> next to index.php.';
    $('play').disabled = !ok;
  }).catch(() => { $('status').innerHTML = '<span class="bad">Backend not reachable.</span>'; });

  $('play').onclick = () => window.open(gameUrl, '_blank', 'noopener');
  $('copy').onclick = async () => {
    try { await navigator.clipboard.writeText(gameUrl); $('copy').textContent = 'Copied'; }
    catch { prompt('Copy this link:', gameUrl); }
    setTimeout(() => $('copy').textContent = 'Copy share link', 1500);
  };
  $('joinBtn').onclick = () => {
    try {
      const u = new URL($('join').value.trim());
      if (!/^https?:$/.test(u.protocol)) throw 0;
      window.open(u.href, '_blank', 'noopener');
    } catch { alert('Enter a full http(s) game link.'); }
  };

  let tips = null;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function renderTips() {
    if (!tips) return;
    $('tips').innerHTML = (tips[$('tabSel').value] || []).map((t, i) =>
      `<details${i ? '' : ' open'}><summary>${esc(t.title)}</summary><ol>${(t.steps || []).map(s => `<li>${esc(s)}</li>`).join('')}</ol></details>`).join('');
  }
  fetch('/troubleshooting.json').then(r => r.json()).then(j => { tips = j; renderTips(); })
    .catch(() => $('tips').textContent = 'Troubleshooting data unavailable.');
  $('tabSel').onchange = renderTips;

  fetch('/wallets.json').then(r => r.json()).then(list => {
    $('wallets').innerHTML = '<div class="mut">Optional donations</div>' + list.map((w, i) =>
      `<details${i ? '' : ' open'} data-w><summary>${esc(w.name)} (${esc(w.symbol)})</summary><code>${esc(w.address)}</code>
       <div class="row"><button class="sec" data-a="${esc(w.address)}">Copy address</button></div></details>`).join('');
    const all = [...document.querySelectorAll('[data-w]')];
    all.forEach(d => d.addEventListener('toggle', () => { if (d.open) all.forEach(o => o !== d && (o.open = false)); }));
    $('wallets').onclick = e => { const a = e.target.dataset && e.target.dataset.a; if (a) navigator.clipboard.writeText(a).catch(() => prompt('Copy:', a)); };
  }).catch(() => {});
})();
