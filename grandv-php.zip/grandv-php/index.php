<?php
// GrandV backend in PHP: static files (Range), /userdata save API, /log, /data/batch, /api/status.
// Dev: php -S 0.0.0.0:8000 index.php     Apache: see .htaccess
declare(strict_types=1);
const ROOT = __DIR__ . '/mirror/playgta5.com'; // game files (you must supply them)
const STORE = __DIR__ . '/storage'; // saves + logs; keep outside web root in production
const MAX_FILE = 32 * 1024 * 1024, MAX_PROFILE = 64 * 1024 * 1024;
@ini_set('zlib.output_compression', '0'); @set_time_limit(0);

function isolation(): void {
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Embedder-Policy: require-corp');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('Accept-Ranges: bytes');
}
function fail(int $code, string $msg): never {
    http_response_code($code); isolation(); header('Content-Type: text/plain'); echo $msg; exit;
}
function safe(string $root, string $rel): string {
    if (preg_match('~[\\\\\0:]~', $rel)) fail(400, 'Invalid path');
    foreach (explode('/', $rel) as $p) if ($p === '' || $p === '.' || $p === '..') fail(400, 'Invalid path');
    $base = realpath($root) ?: fail(404, 'Not found');
    $t = $base . '/' . $rel; $p = $t;
    while (!file_exists($p) && $p !== $base) $p = dirname($p);
    $r = realpath($p);
    if ($r === false || ($r !== $base && !str_starts_with($r, $base . DIRECTORY_SEPARATOR))) fail(403, 'Path escapes root');
    return $t;
}
function valid_save_path(string $p): bool {
    if (!str_starts_with($p, '/userdata/') || strlen($p) > 1024 || preg_match('~[\\\\\0]~', $p)) return false;
    foreach (explode('/', substr($p, 10)) as $s) {
        $n = strtoupper(explode('.', $s)[0]);
        if ($s === '' || $s === '.' || $s === '..' || str_contains($s, ':') || preg_match('~[ .]$~', $s)
            || preg_match('~[\x00-\x1f\x7f]~', $s) || in_array($n, ['CON', 'PRN', 'AUX', 'NUL'], true)
            || preg_match('~^(COM|LPT)[1-9]$~', $n) || $s === '.tombstones.json') return false;
    }
    return true;
}
function profile_ok(string $id): bool { return (bool)preg_match('~^[0-9a-f]{32}$~', $id); }
function b64url_decode(string $s): string|false {
    return base64_decode(strtr(rtrim($s, '='), '-_', '+/'), true);
}
function tombstones(string $root): array {
    $f = $root . '/.tombstones.json';
    if (!is_file($f)) return [];
    $v = json_decode((string)file_get_contents($f), true);
    if (!is_array($v)) fail(500, 'Invalid tombstones'); // fail closed
    if (array_is_list($v)) return array_fill_keys(array_filter($v, 'is_string'), 0);
    return array_map('intval', $v);
}
function atomic_write(string $path, string $data): void {
    @mkdir(dirname($path), 0775, true);
    $tmp = tempnam(dirname($path), '.tmp');
    file_put_contents($tmp, $data) === strlen($data) || fail(500, 'Write failed');
    rename($tmp, $path) || fail(500, 'Rename failed');
}
function set_tomb(string $root, string $key, bool $deleted): void {
    $rows = tombstones($root);
    if ($deleted) $rows[$key] = (int)(microtime(true) * 1000); else unset($rows[$key]);
    atomic_write($root . '/.tombstones.json', json_encode((object)$rows));
}
function profile_dir(string $id): string {
    @mkdir(STORE . '/userdata', 0775, true);
    $root = safe(STORE . '/userdata', $id); @mkdir($root, 0775, true); return $root;
}

$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/');
$method = $_SERVER['REQUEST_METHOD'];
isolation();

if (str_starts_with($path, '/userdata/')) {
    @mkdir(STORE, 0775, true);
    $lock = fopen(STORE . '/.saves.lock', 'c'); flock($lock, LOCK_EX);
    $parts = explode('/', $path);
    if ($method === 'GET') {
        if (count($parts) !== 3 || !profile_ok($parts[2])) fail(400, 'Invalid restore URL');
        $root = profile_dir($parts[2]); $deleted = tombstones($root); $files = []; $total = 0;
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
        foreach ($it as $e) {
            if (!$e->isFile() || $e->isLink()) continue;
            $rel = str_replace('\\', '/', substr($e->getPathname(), strlen($root) + 1));
            if (isset($deleted[$rel]) || !valid_save_path("/userdata/$rel")) continue;
            $total += $e->getSize();
            if ($e->getSize() > MAX_FILE || $total > MAX_PROFILE) fail(500, 'Profile exceeds restore limit');
            $files[] = ['path' => "/userdata/$rel", 'data' => base64_encode(file_get_contents($e->getPathname())), 'mtime' => $e->getMTime() * 1000];
        }
        $tombs = [];
        foreach ($deleted as $p => $t) if (valid_save_path("/userdata/$p")) $tombs[] = ['path' => "/userdata/$p", 'mtime' => $t];
        header('Content-Type: application/json'); echo json_encode(['files' => $files, 'tombstones' => $tombs]); exit;
    }
    if ($method !== 'PUT' && $method !== 'DELETE') fail(405, 'Unsupported userdata method');
    if (count($parts) !== 4 || !profile_ok($parts[2])) fail(400, 'Invalid userdata URL');
    $decoded = b64url_decode($parts[3]);
    if ($decoded === false || !valid_save_path($decoded)) fail(400, 'Invalid userdata path');
    $root = profile_dir($parts[2]); $rel = substr($decoded, 10); $target = safe($root, $rel);
    if ($method === 'DELETE') {
        set_tomb($root, $rel, true); @unlink($target); http_response_code(204); exit;
    }
    $body = (string)file_get_contents('php://input');
    if (strlen($body) > MAX_FILE) fail(413, 'Save exceeds 32 MiB');
    $size = strlen($body);
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)) as $e)
        if ($e->isFile() && $e->getPathname() !== $target && $e->getFilename() !== '.tombstones.json') $size += $e->getSize();
    if ($size > MAX_PROFILE) fail(413, 'Profile exceeds 64 MiB');
    tombstones($root);
    atomic_write($target, $body);
    $ms = (float)($_SERVER['HTTP_X_USERDATA_MTIME'] ?? 0);
    if (is_finite($ms) && $ms > 0 && $ms < 4102444800000.0) @touch($target, (int)($ms / 1000));
    set_tomb($root, $rel, false); http_response_code(204); exit;
}

if ($path === '/log' && $method === 'POST') {
    @mkdir(STORE, 0775, true);
    $text = str_replace("\0", '', substr((string)file_get_contents('php://input'), 0, 256 * 1024));
    $log = STORE . '/server.log';
    if (is_file($log) && filesize($log) > 4 * 1024 * 1024) rename($log, $log . '.1');
    file_put_contents($log, rtrim($text, "\n") . "\n", FILE_APPEND | LOCK_EX);
    http_response_code(204); exit;
}

if ($path === '/data/batch' && $method === 'POST') {
    $runs = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($runs) || count($runs) > 1000) fail(400, 'Too many batch runs');
    $sel = []; $total = 0;
    foreach ($runs as $r) {
        if (!is_array($r) || count($r) !== 3 || !is_string($r[0]) || !is_int($r[1]) || !is_int($r[2]) || $r[1] < 0 || $r[2] < $r[1]) fail(400, 'Invalid range');
        $file = safe(ROOT . '/data', $r[0]);
        $size = is_file($file) ? filesize($file) : fail(404, 'Not found');
        $len = max(0, min($r[2] + 1, $size) - $r[1]);
        if (($total += $len) > 64 * 1024 * 1024) fail(413, 'Batch exceeds 64 MiB');
        $sel[] = [$file, $r[1], $len];
    }
    $out = '';
    foreach ($sel as [$f, $s, $l]) { $h = fopen($f, 'rb'); fseek($h, $s); $out .= (string)fread($h, $l); fclose($h); }
    header('X-Run-Lengths: ' . implode(',', array_column($sel, 2)));
    header('Content-Type: application/octet-stream');
    if (($_GET['gz'] ?? '') === '1') { $out = gzencode($out, 1); header('Content-Encoding: gzip'); }
    header('Content-Length: ' . strlen($out)); echo $out; exit;
}

if ($path === '/api/status') {
    header('Content-Type: application/json'); header('Cache-Control: no-store');
    echo json_encode(['gameFolder' => is_dir(ROOT), 'hasLauncher' => is_file(ROOT . '/launcher.html'),
        'multiplayer' => false, 'php' => PHP_VERSION]); exit;
}

if ($method !== 'GET' && $method !== 'HEAD') fail(404, 'Not found');
if ($path === '/' ) $path = '/grandv-launcher.html';
if (in_array($path, ['/grandv-launcher.html', '/grandv-launcher.js', '/wallets.json', '/troubleshooting.json', '/grand-logo-v2.png'], true)) {
    $file = __DIR__ . $path;
} else {
    $rel = ltrim($path, '/'); $file = $rel === '' ? ROOT : safe(ROOT, $rel);
    if (is_dir($file)) $file = rtrim($file, '/') . '/index.html'; // no directory listings
}
if (!is_file($file)) fail(404, 'Not found');
$size = filesize($file); $start = 0; $end = $size - 1;
if (!empty($_SERVER['HTTP_RANGE'])) {
    if (!preg_match('~^bytes=(\d*)-(\d*)$~', $_SERVER['HTTP_RANGE'], $m) || ($m[1] === '' && $m[2] === '') || $size === 0) {
        http_response_code(416); header("Content-Range: bytes */$size"); exit;
    }
    if ($m[1] === '') { $start = max(0, $size - (int)$m[2]); }
    else { $start = (int)$m[1]; if ($m[2] !== '') $end = min((int)$m[2], $size - 1); }
    if ($start >= $size || $end < $start) { http_response_code(416); header("Content-Range: bytes */$size"); exit; }
    http_response_code(206); header("Content-Range: bytes $start-$end/$size");
}
$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$mime = ['wasm' => 'application/wasm', 'js' => 'text/javascript', 'mjs' => 'text/javascript', 'html' => 'text/html; charset=utf-8',
    'css' => 'text/css', 'json' => 'application/json', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'svg' => 'image/svg+xml',
    'ogg' => 'audio/ogg', 'mp3' => 'audio/mpeg', 'wav' => 'audio/wav'][$ext] ?? 'application/octet-stream';
header("Content-Type: $mime"); header('Content-Length: ' . ($end - $start + 1));
if ($method === 'HEAD') exit;
$h = fopen($file, 'rb'); fseek($h, $start); $left = $end - $start + 1;
while ($left > 0 && !feof($h)) { $c = fread($h, min(65536, $left)); if ($c === false || $c === '') break; echo $c; $left -= strlen($c); flush(); }
