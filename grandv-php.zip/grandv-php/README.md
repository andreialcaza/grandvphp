# GrandV backend — HTML / JS / PHP port

Requires PHP 8.1+. Put your own game files at `mirror/playgta5.com/` (it must contain `launcher.html`).

- Dev: `php -S 0.0.0.0:8000 index.php` then open http://localhost:8000
- Apache: upload everything; `.htaccess` routes all requests via `index.php` (needs mod_rewrite). Keep `storage/` unreachable from the web.
- Launcher page: `/` · Game: `/launcher.html` (from `mirror/playgta5.com/`)

Ported: static serving with Range + COOP/COEP/CORP, `/userdata` save API (same URL/base64url scheme, tombstones, size limits), `/log`, `/data/batch` (+gz, X-Run-Lengths).
Not ported (native-only): multiplayer WebSocket relay, LAN CA/TLS generation, UDP discovery, Cloudflare tunnel management, native console, per-IP bandwidth limits.
